%**************************************************************************
% Transient Inverse Sourse Probem
%**************************************************************************
%  
% DESCRIPTION
% Computes first and second order topological derivatives and use them 
% in the reconstruction of time-dependent distributed sources from partial 
% boundary measurement. Version: fractional time derivative (0 < alpha < 1)
% Remark: CCBM formulation
%
% HISTORY
% A.A. Novotny     02/2021: code implementation
%**************************************************************************

clear all; format short; 
% load problem data
cd('examples')
    [mesh, grid, pdecoef, params] = exeX;
cd ..

% mesh and grid parameters
p = mesh.p; e = mesh.e; t = mesh.t; g = mesh.g; pb = getpb(e); 
area = mesh.area; np = size(p,2); nt = size(area,2);

% grid  parameter
loc = grid.loc; ng = size(loc,1); 
pgd = grid.pgd; egd = grid.egd; tgd = grid.tgd;

% pdetool coefficients
c = pdecoef.c; fs = pdecoef.fs;
a = pdecoef.a; U0 = pdecoef.U0;
f = pdecoef.f; br = pdecoef.br; 

% parameters
nlevel = params.nlevel; flag = params.flag; nb = params.nb; ft = params.ft;

% time discretization parameters
dt = params.dt; t1 = params.t1; t2 = params.t2; 
n = params.n; alpha = params.alpha; dta = dt^alpha;

% plot mesh
figure(1); clf; set(1,'WindowStyle','docked');
pdemesh(p,e,t); axis image; axis off; title('mesh');

% plot grid
aux = zeros(np,1); aux(loc) = 1.0; 
figure(2); clf; set(2,'WindowStyle','docked'); aux =-aux;
pdeplot(p,e,t,'xydata',aux,'xystyle','interp','colormap','gray',...
              'xygrid','off','colorbar','off'); 
set(gca,'XColor','k','YColor','k','LineWidth',2);  
set(gca,'XTick',[],'YTick',[],'Ztick',[]);  
axis image; box on; title('grid');

% add noise
if(flag == 0)
    noise = randn(np,1); 
    save noise.mat noise 
elseif(flag == 1)
    load noise.mat
end
noise = pdeintrp(p,t,noise); fc = zeros(nb,nt);
for i = 1:nb
    fc(i,:) = fs(i,:) + nlevel*noise;
end

% plot target
psi0 = zeros(1,nt);
for i = 1:nb
    psi0 = psi0 + fc(i,:);
end

figure(3); clf; set(3,'WindowStyle','docked');
pdeplot(p,e,t,'xydata',-psi0,'xystyle','interp','colormap','gray',...
              'xygrid','off','colorbar','off'); 
set(gca,'XColor','k','YColor','k','LineWidth',2);  
set(gca,'XTick',[],'YTick',[],'Ztick',[]);  
axis image; box on; title('target');

% calculate the target function z
[K,M,~] = assema(p,t,c,a,0); beta0 = beta(0,alpha);
Ad = (K + M) * dta + beta0 * M; npb = size(pb,1); 
Ad(pb,:) = 0.0; Ad(:,pb) = 0.0; Ad(pb,pb) = speye(npb);  

Fs = zeros(np,nb);
for i=1:nb
    [~,~,Fi] = assema(p,t,c,a,fc(i,:));
    Fs(:,i) = Fi;
end 

Z = U0; 
for j=1:n % Time  
    Fi = zeros(np,1);
    for i=1:nb
        Fi = Fi + Fs(:,i)*ft(i,j)*dta;
    end     
    Fk = zeros(np,1);
    for k=1:j-1
        Zk = Z(:,j-k+1);
        beta1 = beta(k-1,alpha); 
        beta2 = beta(k,alpha); 
        Fk = Fk + (beta2-beta1)*M*Zk;
    end 
    Fj = Fi - Fk; Fj(pb) = 0.0; 
    Zj = Ad \ Fj; Z = cat(2,Z,Zj);    
end

[Mb,~] = assempde(br,p,e,t,0,0,0); 
B = K + M + Mb; A = B * dta + beta0 * M;   

% compute auxiliary problem
U = U0;  
for j=1:n % Time 
    Fk = zeros(np,1); Fz = zeros(np,1); 
    Q = K * Z(:,j+1); Fz(pb) = Q(pb);
    for k=1:j-1
        Uk = U(:,j-k+1);
        beta1 = beta(k-1,alpha); 
        beta2 = beta(k,alpha); 
        Fk = Fk + (beta2-beta1)*M*Uk;
    end 
    Fj = Fz*dta - Fk; % + Fi;  
    Uj = A \ Fj; U = cat(2,U,Uj);   
end

% compute the canonical solutions
htab = zeros(np,ng); pos = 0; 
xp = p(1,:)'; xg = pgd(1,:)';
yp = p(2,:)'; yg = pgd(2,:)'; 
for i = 1:ng
    % solving linear system for Qi
    dx = xp-xg(loc(i)); dy = yp-yg(loc(i));
    aux = sqrt(dx.^2 + dy.^2); 
    pQ =-besselk(0,aux); pQ(loc(i)) = 0.0;
    Fd = Mb * pQ; Qb = K * pQ; Fn = zeros(np,1); 
    Fn(pb) = Qb(pb); F = Fn + Fd;
    Qi = B \ F; htab(:,i) = imag(Qi); % assemble qtab
    pos = pos + 1; disp(['node = ' , num2str(pos), '/' num2str(ng)]);
end

% compute first and second order topological derivatives
dt1 = zeros(ng,1); dt2 = zeros(ng,ng);  
iU = imag(U); pos = 0; auxi = zeros(np,1);
for i = 1:n % time integral
    aux1 = iU(:,i); aux2 = iU(:,i+1);
    auxi = auxi + 0.5*(aux1+aux2)*dt;
end

for i = 1:ng
    Vi = htab(:,i);
    dt1(i) = dot(M*Vi,auxi) + dot(K*Vi,auxi);
    for j = 1:ng
        Vj = htab(:,j);        
        dt2(i,j) = (t2-t1)*dot(M*Vi,Vj) + (t2-t1)*dot(K*Vi,Vj);
    end
    pos = pos + 1; disp(['node = ' , num2str(pos), '/' num2str(ng)]);     
end

% Find best balls
[sfs,ns,as] = findm(nb,ng,dt1,dt2); 

% print search results
x = p(1,:); y = p(2,:);
rs = sqrt(2.0*as); psi = zeros(np,1);
for i = 1:nb
    nsi = loc(ns(i)); rsi = rs(i);
    xsi = p(1,nsi); ysi = p(2,nsi); 
    node = ((x-xsi).^2 + (y-ysi).^2 <= rsi^2); psi(node) = 1.0; 
    disp(' ');
    disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
    disp([' -> ball ' num2str(i)]);
    disp(['    x* = (',num2str(xsi),',',num2str(ysi),')']);
    disp(['    e* = ' num2str(rs(i))]);
    disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');    
end

% Plot Result
figure(4); clf; set(4,'WindowStyle','docked');
pdeplot(p,e,t,'xydata',-psi,'xystyle','interp','colormap','gray',...
              'xygrid','off','colorbar','off'); 
set(gca,'XColor','k','YColor','k','LineWidth',2);  
set(gca,'XTick',[],'YTick',[],'Ztick',[]);  
axis image; box on; title('result'); 
                 
