function bn = beta(n,alpha)

    bn = (n + 1.0)^(1.0-alpha) - n^(1.0-alpha);
    bn = bn / gamma(2.0 - alpha);
    
end