function pb = getpb(e)
bp1 = (e(6,:)==0|e(7,:)==0); % reading interior nodes
bp2 = bp1.*e(1,:); % N� inicial 
bp3 = bp1.*e(2,:); % N� final
pb  = [bp2,bp3]; pb = nonzeros(pb); pb = unique(pb);
end

%%% Por que precisa definr bp3? N�o bastava definir bp2 e encerrar a
%%% fun��o?