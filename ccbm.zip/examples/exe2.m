function [mesh, grid, pdecoef, params] = exe2
    %% geometry
    p = [ 0, 0;
          1, 0;
          1, 1;
          0, 1];
    g = [2; size(p,1); p(:,1); p(:,2)]; 
    % composing the geometry
    g = decsg(g);     
    
    %% mesh and grid generation
    remesh  = 'longest';
    [p,e,t] = poimesh(g,10,10);
    [p,e,t] = refinemesh(g,p,e,t,remesh); 
    np = size(p,2); pg = 1:np; pg = pg';
    pb = getpb(e); pg = setdiff(pg,pb); 

    grid.pgd = p;
    grid.egd = e;
    grid.tgd = t;
    grid.loc = pg;    

    % mesh
    nsteps = 3; 
    for i=1:nsteps*2
       [p,e,t] = refinemesh(g,p,e,t,remesh); 
    end
    area = pdetrg(p,t); np = size(p,2);

    mesh.p = p;
    mesh.e = e;
    mesh.t = t;
    mesh.g = g;
    mesh.area = area;  
    
    %% boundary condition and measures
    
    % bc auxiliaries problem
    ik = complex(0,10.0);
    ik = mat2str(ik);
    nq = size(ik,2);
    
    % bc auxiliaries problems
    br = [1 0 nq 1 ik '0']';
    br = repmat(br,1,4);        

    %% parameters

    % noise level 
    params.nlevel = 0.0; 
    % flag = 0 realization does not exist
    % flag = 1 realization already exists
    params.flag = 0;

    % number of trial balls
    nb = 2; params.nb = nb;     
        
    % time discretization parameters
    n = 100; t1 = 0; t2 = 1.0; dt = (t2-t1)/n; 
       
    params.dt = dt; 
    params.t1 = t1;  
    params.t2 = t2; 
    params.n = n;
    params.alpha = 0.5; % 0 < alpha < 1          
    
    %% target
    
    % mu(t)
    ft = zeros(nb,n+1);
    for i = 1:n+1
        time = dt*(i-1);
        if (time >= 0.0*(t2-t1) && time < 0.1*(t2-t1)) 
            ft(1,i) = 10.0;
        end
        if (time >= 0.2*(t2-t1) && time < 0.4*(t2-t1)) 
            ft(2,i) = 5.0;
        end        
    end
    params.ft = ft;    

    nt = size(area,2); fs = zeros(nb,nt);
    tx = pdeintrp(p,t,p(1,:)');  ty = pdeintrp(p,t,p(2,:)');
    R2 = 0.05^2; cx = 0.6; cy = 0.7;
    el = ((tx-cx).^2 + (ty-cy).^2 <= R2); fs(1,el) = 1;
    R2 = 0.10^2; cx = 0.4; cy = 0.4;
    el = ((tx-cx).^2 + (ty-cy).^2 <= R2); fs(2,el) = 1;
    
    %% pde coeficients  

    pdecoef.c = 1.0;
    pdecoef.a = 1.0;  
    pdecoef.f = 0.0;
    pdecoef.fs = fs;
    pdecoef.br = br;  
    pdecoef.U0 = zeros(np,1); % initial condition    
    
end