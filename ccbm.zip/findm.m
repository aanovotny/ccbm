% function [sfs,ns,as] = findbestsf(nb,ng,dt,dt2)
% 
% sfs = inf; ns = 0; as = 0;
% for i = 1:ng
%     [sfsi,nsi,asi] = findbestsfint(i,nb,ng,dt,dt2);
%     if (sfsi<sfs)
%         sfs = sfsi; ns = nsi; as = asi;
%     end
%     disp(['node = ' , num2str(i), '/' num2str(ng)]);
% end

function [sfs,ns,as] = findm(nb,ng,dt,dt2)

if nb == 1 
    ns = 0; as = 0; sfs = inf;
    for i = 1:ng
        dt1i = dt(i); dt2ii = dt2(i,i);
        ai = - dt1i / dt2ii;
        if (ai > 0)
            sfe = 0.5 * dt1i * ai;
            if (sfe < sfs)
                sfs = sfe; ns = i; as = ai;
            end
        end;
        disp(['node = ' , num2str(i), '/' num2str(ng)]);    
    end;
end;


if nb == 2
    sfs = inf; ns = zeros(nb,1); as = zeros(nb,1);
    for i = 1:ng
        for j = i+1:ng
            dt1i = dt(i);
            dt1j = dt(j);
            vdt1 = [dt1i; dt1j];
            mdt2 = [dt2(i,i), dt2(i,j);
                    dt2(j,i), dt2(j,j)];
            va = - mdt2 \ vdt1;
            if all(va > 0)
                sfe = 0.5*dot(vdt1,va);
                if (sfe < sfs)
                    sfs = sfe; ns = [i;j]; as = va;
                end;
            end;
        end;
        disp(['node = ' , num2str(i), '/' num2str(ng)]);
    end;
end;


if nb == 3
    sfs = inf; ns = zeros(nb,1); as = zeros(nb,1);
    for i = 1:ng
        for j = i+1:ng
            for k = j+1:ng
                vdt1 = [dt(i);dt(j);dt(k)];
                mdt2 = [dt2(i,i), dt2(i,j), dt2(i,k);
                        dt2(j,i), dt2(j,j), dt2(j,k);
                        dt2(k,i), dt2(k,j), dt2(k,k)];
                va = - mdt2 \ vdt1;
                if all(va > 0)
                    sfe = 0.5*dot(vdt1,va);
                    if (sfe < sfs)
                        sfs = sfe; ns = [i;j;k]; as = va;
                    end;
                end;
            end;
        end;
        disp(['node = ' , num2str(i), '/' num2str(ng)]);
    end;
end;


if nb == 4
    sfs = inf; ns = zeros(nb,1); as = zeros(nb,1);
    for i = 1:ng
        disp('------------------------------');
        disp(['node i = ' , num2str(i), '/' num2str(ng)]);
        disp('------------------------------');
        for j = i+1:ng
            disp(['node j = ' , num2str(j), '/' num2str(ng)]);
            for k = j+1:ng
                for l = k+1:ng
                    vdt1 = [dt(i);dt(j);dt(k);dt(l)];
                    mdt2 = [dt2(i,i), dt2(i,j), dt2(i,k), dt2(i,l);
                            dt2(j,i), dt2(j,j), dt2(j,k), dt2(j,l);
                            dt2(k,i), dt2(k,j), dt2(k,k), dt2(k,l);
                            dt2(l,i), dt2(l,j), dt2(l,k), dt2(l,l)];
                    va = - mdt2 \ vdt1;
                    if all(va > 0)
                        sfe = 0.5*dot(vdt1,va);
                        if (sfe < sfs)
                            sfs = sfe; ns = [i;j;k;l]; as = va;
                        end;
                    end;
                end;
            end;
        end;
    end;
end;